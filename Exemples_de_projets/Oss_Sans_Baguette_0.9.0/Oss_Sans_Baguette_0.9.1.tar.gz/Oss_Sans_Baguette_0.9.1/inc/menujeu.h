#ifndef __MENUJEU_H__
#define __MENUJEU_H__

int bouclejeu(void);
int regle(void);
int credits(void);
int choix_menujeu(void);
int ficheperso(void);
int option(void);

#define QUITTER     5

#endif
