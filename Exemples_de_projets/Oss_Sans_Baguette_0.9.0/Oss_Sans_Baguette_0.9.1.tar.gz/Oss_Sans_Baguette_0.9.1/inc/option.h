#ifndef __OPTION_H__
#define __OPTION_H__

int menu_option(void);

#endif
