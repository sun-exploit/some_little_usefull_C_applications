/*
 * Fichier d'en tête extraction.h pour le projet test_strtok
 * Auteur : Eric Bachard  / samedi 4 juin 2016, 13:35:52 (UTC+0200)
 * Ce document est sous Licence GPL v2
 * voir : http://www.gnu.org/licenses/gpl-2.0.html
 */

#ifndef __EXTRACTION__H__
#define __EXTRACTION__H__

short int extraction_donnees(void);
short int remplissage_tableau(short int, short int, char *, char *, char *, char *, char*, BOOL, BOOL, BOOL, BOOL);

#endif /* __EXTRACTION__H__ */

