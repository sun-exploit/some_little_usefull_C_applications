#include <stdio.h>
#include <stdlib.h>
#include "nettoyage_ecran.h"

int credits()
{
#ifndef DEBUG
  nettoyage_ecran();
#endif
  fprintf(stdout, "Ce jeu vous a été offert par l’équipe BLARP.\n");
  fprintf(stdout, "Baloute, Lag, Anium, Raton et Péri, vous remercient d'avoir joué dans la joie et la bonne humeur.\n");
  fprintf(stdout, "Merci également à M.Bachard pour son aide et ses conseils nous donnant ainsi la possibilité de créer ce jeu !\n");
  fprintf(stdout, "See U Soon, Maybe ! Si vous aimez ces petites bestioles, n'hésitez pas à faire un tour sur leur page Facebook !\n");
  fprintf(stdout, "(https://www.facebook.com/Jungilos/)\n");

  return EXIT_SUCCESS;
}
