#include <stdlib.h>
#include <stdio.h>

#include "boolean.h"
#include "saisie_chaine.h"
#include "saisie_nombre.h"
#include "nettoyage_ecran.h"

int regle(void)
{
  int choix = 0;
  BOOL b_Quitter = FALSE;

  do
  {
#ifndef DEBUG
    nettoyage_ecran();
#endif
    fprintf(stdout, "\n\t\t=== Oss Sans Baguette ===\n\n");
    fprintf(stdout, "\t\tRègles du jeu\n\n");

    fprintf(stdout, "\t   Bonjour et bienvenue dans OSS Sans Baguette !\n\n\tC'est un jeu RP (jeu de rôle) dans lequel vous incarnez Mépo, un Jungilos,\n\tchargé d'aller chercher du pain à la boulangerie.\n\n\tVous vous déplacerez à l'aveugle dans un labyrinthe à l'aide de la console et\n\tdes chiffres de 1 à 4.\n\n\tVos déplacements et vos actions seront narrées pour une immersion totale.\n\n\tNous vous conseillons alors de dessiner une carte sur papier pour ne pas vous\n\tperdre, car vous serez amené à trouver de l'argent avant d'aller acheter du pain.\n\n\tL'équipe BLARP vous souhaite une expérience de jeu agréable\n\tet vous remercie de jouer !\n\n");

      fprintf(stdout, "\t\t1 - Quitter\n");
      fprintf(stdout, "\n");

      choix = saisie_nombre_entier_court( FALSE, FALSE, 1, 1);

      if (choix == 1)
        b_Quitter = TRUE;

    }  while ( FALSE == b_Quitter );

  return EXIT_SUCCESS;
}
