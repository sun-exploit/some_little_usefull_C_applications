/* fichier .c (fait partie de OSS_Sans_Baguette)
 * Auteur:  BLARP  / mercredi 11 mai 2016, 07:14:11 (UTC+0200)
 * Ce document est sous Licence : GPL v2
 * voir : http://www.gnu.org/licenses/gpl-2.0.html
 */

#include <stdio.h>
#include <stdlib.h>

void nettoyage_ecran(void)
{
  short int anErr = system ("clear");
  if (anErr != 0 )
    fprintf(stdout, "problème de nettoyage de l'écran\n");
}

