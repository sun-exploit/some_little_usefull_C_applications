#include <stdlib.h>
#include <stdio.h>

#include "menujeu.h"
#include "boolean.h"
#include "saisie_nombre.h"
#include "nettoyage_ecran.h"

#define CHOIX_JEU            1
#define CHOIX_REGLE          2
#define CHOIX_FICHE_PERSO    3
#define SECRET_OPTION        666
#define CHOIX_QUITTER        4

int menujeu(void)
{
  BOOL b_Quitter = FALSE;
  do
  {
#ifndef DEBUG
    nettoyage_ecran();
#endif
    fprintf(stdout, "\n\t\t=== Oss Sans Baguette ===\n\n");
    switch (choix_menujeu())
    {
      case CHOIX_JEU:
        bouclejeu();
        break;

      case CHOIX_REGLE:
        regle();
        break;

      case CHOIX_FICHE_PERSO:
        ficheperso();
        break;

      case CHOIX_QUITTER: 
        b_Quitter = TRUE;
        break;

      case SECRET_OPTION:
        option();
        break;

    }
  } while ( FALSE == b_Quitter );
  credits();
  return EXIT_SUCCESS;
}
