#include <stdlib.h>
#include <stdio.h>

#include "fonction_jeu.h"
#include "nettoyage_ecran.h"

int bouclejeu(void)
{
#ifndef DEBUG
  nettoyage_ecran();
#endif
  tableau();
  return EXIT_SUCCESS;
}
