#include <stdio.h>
#include <stdlib.h>

#include "boolean.h"
#include "saisie_nombre.h"
#include "nettoyage_ecran.h"

int choix_menujeu()
{
  int action = 0;
  BOOL define = FALSE;

  while ((action < 1 || action > 4) && (action != 666))
  {
    if (define == FALSE)
    {
      fprintf(stdout, "\n\t1 - Jouer\n");
      fprintf(stdout, "\t2 - Règles\n");
      fprintf(stdout, "\t3 - Fiche personnage\n");
      fprintf(stdout, "\t4 - Quitter\n");
      fprintf(stdout, "\n");
      define = TRUE;
    }
      action = saisie_nombre_entier_court( FALSE, FALSE, 1, 666);
  }
#ifndef DEBUG
  nettoyage_ecran();
#endif
  return action;
}
