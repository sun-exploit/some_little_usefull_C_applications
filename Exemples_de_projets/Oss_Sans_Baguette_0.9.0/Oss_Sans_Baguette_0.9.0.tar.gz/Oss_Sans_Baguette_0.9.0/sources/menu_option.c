#include <stdio.h>
#include <stdlib.h>

#include "boolean.h"
#include "saisie_nombre.h"
#include "nettoyage_ecran.h"

int menu_option()
{
  int action = 0;

  while (action < 1 || action > 5)
  {
      fprintf(stdout, "\n\t1 - Classique\n");
      fprintf(stdout, "\t2 - Calme\n");
      fprintf(stdout, "\t3 - Pixel\n");
      fprintf(stdout, "\t4 - Innocent\n");
      fprintf(stdout, "\t5 - Retour\n");
      fprintf(stdout, "\n");
      action = saisie_nombre_entier_court( FALSE, FALSE, 1, 5);
  }
#ifndef DEBUG
  nettoyage_ecran();
#endif
  return action;
}
