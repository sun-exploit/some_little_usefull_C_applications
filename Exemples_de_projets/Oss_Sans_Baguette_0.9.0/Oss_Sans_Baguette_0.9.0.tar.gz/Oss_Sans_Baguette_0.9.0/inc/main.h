#ifndef __MAIN_H__
#define __MAIN_H__

int menujeu(void);

#endif
