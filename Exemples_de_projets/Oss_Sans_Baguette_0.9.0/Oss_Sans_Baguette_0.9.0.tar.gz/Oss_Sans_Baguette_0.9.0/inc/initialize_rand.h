/* initialize_rand.h fichier d'en tete */
/*
 * Auteur:  Eric Bachard  / 3 novembre 2014
 * Ce document est sous Licence GPL v2
 * voir : http://www.gnu.org/licenses/gpl-2.0.html
 */

#ifndef __INITIALIZE_TIME_H
#define __INITIALIZE_TIME_H

void initialize_rand(void);

#endif /* __INITIALIZE_TIME_H */
