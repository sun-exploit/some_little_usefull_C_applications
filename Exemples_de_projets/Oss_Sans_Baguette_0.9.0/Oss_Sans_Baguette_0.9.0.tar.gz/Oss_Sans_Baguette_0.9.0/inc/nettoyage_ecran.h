/*
 * Fichier d'en tête nettoyage_ecran.h pour le projet OSS_Sans_Baguette
 * Auteur : BLARP  / dimanche 5 juin 2016, 08:43:46 (UTC+0200)
 * Ce document est sous Licence GPL v2
 * voir : http://www.gnu.org/licenses/gpl-2.0.html
 */

#ifndef __NETTOYAGE_ECRAN__H__
#define __NETTOYAGE_ECRAN__H__

void nettoyage_ecran(void);

#endif /* __NETTOYAGE_ECRAN__H__ */

