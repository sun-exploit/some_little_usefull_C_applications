#ifndef __FONCTION_JEU_H__
#define __FONCTION_JEU_H__

int tableau(void);
int menu_etape(short int, short int);
char *lieu(void);

#endif
