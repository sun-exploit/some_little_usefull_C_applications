
/* efface_ecran.h fichier d'en tete */
/*
 * Auteur:  Eric Bachard  / 3 novembre 2004
 * Ce document est sous Licence MIT
 * voir efface_ecran.h_LICENCE.txt dans le répertoire parent
 */

#ifndef __EFFACE_ECRAN_H
#define __EFFACE_ECRAN_H

void efface_ecran(void);

#endif /* __EFFACE_ECRAN_H */